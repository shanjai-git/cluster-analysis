# Customer Segmentation Project

Segment customers by **behaviour** (RFM, discount use, returns), **preferences** (channel, category) and **demographics** (age, income, tenure) using Python / scikit-learn, then turn the segments into marketing actions. A Power BI guide is included for the dashboard layer.

## Headline result
Five segments found. **14% of customers (Premium Loyalists) drive ~50% of revenue**, while 15% (At-Risk Veterans) are valuable customers who have gone quiet for ~6 months - the most urgent win-back target.

![segments](outputs/figures/02_segments_pca.png)

## Quick start
```bash
pip install -r requirements.txt
python src/generate_data.py     # builds data/*.csv (synthetic; skip to use your own data)
python src/segmentation.py      # runs everything, writes outputs/
jupyter notebook notebooks/customer_segmentation.ipynb   # step-by-step walkthrough
```
Or run `./run_all.sh`. Outputs are already included in this zip, so you can browse results without running anything. Everything is seeded (`random_state=42`) and reproducible.

## Project structure
```
customer_segmentation/
├── README.md
├── requirements.txt / run_all.sh
├── data/
│   ├── customers.csv                  # 2,500 customers (demographics)
│   ├── transactions.csv               # 32,877 orders
│   └── _ground_truth_for_validation_only.csv   # hidden persona, NEVER used for clustering
├── src/
│   ├── generate_data.py               # synthetic data generator
│   └── segmentation.py                # full pipeline (features -> k -> models -> profiles -> charts)
├── notebooks/customer_segmentation.ipynb      # guided walkthrough (run it to see outputs)
├── outputs/
│   ├── customers_segmented.csv        # <- one row per customer incl. segment (Power BI ready)
│   ├── transactions_segmented.csv
│   ├── figures/                       # 10 charts
│   └── tables/                        # segment profiles, k-selection, model comparison, validation
├── powerbi/POWERBI_GUIDE.md           # data model, DAX measures, page layouts
└── docs/report.md                     # business findings, actions, limitations
```

## Methodology in one minute
1. **Features** - Recency/Frequency/Monetary, AOV, discount usage, channel & category shares, age, income, tenure (15 total). Skewed variables log-transformed, all standardised.
2. **Choose k** - elbow, silhouette, Davies-Bouldin, Calinski-Harabasz **and bootstrap stability**, restricted to 4-7 segments (business-actionable). Result: k = 5.
3. **Compare algorithms** - K-Means vs Ward hierarchical vs Gaussian Mixture (all agree closely). K-Means used as final.
4. **Profile & name** - segment means, revenue share, preferences; names assigned by optimal matching to archetype recipes.
5. **Validate** - compared with the hidden generating personas (ARI 0.91, 96% of customers matched).

## Using your own data
Replace the two CSVs in `data/` keeping these columns, then run `python src/segmentation.py` (delete `_ground_truth_for_validation_only.csv` - validation is skipped automatically).

| customers.csv | transactions.csv |
|---|---|
| customer_id, age, gender, city, annual_income_k, tenure_years | transaction_id, customer_id, order_date, category, channel, quantity, discount_pct, order_value, returned (0/1) |

If your categories/channels differ, edit `CLUSTER_FEATURES` and `ARCHETYPES` at the top of `src/segmentation.py` (the segment *names* and ARCHETYPE matching are tuned to the 5 synthetic personas; with real data, k may differ and segments fall back to descriptive names like "Segment 2: High-value, recently active" which you can rename).

## Caveats
Data is synthetic, so the clean separation (and the 0.91 recovery score) is optimistic compared with real-world data. See `docs/report.md` section 6.
