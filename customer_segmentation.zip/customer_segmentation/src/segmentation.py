"""
Customer Segmentation pipeline
==============================
1. Load customers + transactions
2. Feature engineering (RFM + behaviour + preferences + demographics)
3. Scale features, choose k (elbow, silhouette, Davies-Bouldin)
4. Fit K-Means, compare against Hierarchical & Gaussian Mixture
5. Profile + name segments, generate marketing actions
6. Save charts, tables and Power BI-ready CSVs

Run:  python src/segmentation.py
"""
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score, adjusted_rand_score

warnings.filterwarnings("ignore")
RANDOM_STATE = 42
MIN_SEGMENTS, MAX_SEGMENTS = 4, 7   # business constraint: enough segments to target, few enough to run campaigns for
ROOT = Path(__file__).resolve().parents[1]
DATA, FIG, TAB = ROOT / "data", ROOT / "outputs" / "figures", ROOT / "outputs" / "tables"
for p in (FIG, TAB):
    p.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid", context="notebook")
PALETTE = ["#4C78A8", "#F58518", "#54A24B", "#E45756", "#B279A2", "#72B7B2"]
# one fixed colour per segment so every chart is comparable
SEG_COLORS = {"Premium Loyalists": "#E4A81C", "Young Digital Shoppers": "#4C78A8",
              "Budget Families": "#54A24B", "Occasional Browsers": "#9AA0A6", "At-Risk Veterans": "#E45756"}


def seg_color(name, i=0):
    return SEG_COLORS.get(name, PALETTE[i % len(PALETTE)])


def seg_palette(names):
    return {n: seg_color(n, i) for i, n in enumerate(names)}


# ------------------------------------------------------------------ 1. LOAD
def load_data():
    customers = pd.read_csv(DATA / "customers.csv")
    tx = pd.read_csv(DATA / "transactions.csv", parse_dates=["order_date"])
    return customers, tx


# ------------------------------------------------------- 2. FEATURE ENGINEERING
def build_features(customers, tx):
    snapshot = tx["order_date"].max() + pd.Timedelta(days=1)
    # Recency & frequency use all orders; revenue (monetary / AOV) ignores returned orders
    rf = tx.groupby("customer_id").agg(
        recency_days=("order_date", lambda s: (snapshot - s.max()).days),
        frequency=("transaction_id", "count"),
    )
    money = tx.assign(net=tx["order_value"] * (1 - tx["returned"])).groupby("customer_id").agg(
        monetary=("net", "sum"), avg_order_value=("order_value", "mean"))
    rfm = rf.join(money)
    beh = tx.groupby("customer_id").agg(
        discount_usage=("discount_pct", lambda s: (s > 0).mean()),
        return_rate=("returned", "mean"),
        avg_items=("quantity", "mean"),
    )
    # share of orders in each category / channel (customer preferences)
    cat_share = pd.crosstab(tx["customer_id"], tx["category"], normalize="index").add_prefix("cat_")
    ch_share = pd.crosstab(tx["customer_id"], tx["channel"], normalize="index").add_prefix("ch_")
    df = (customers.set_index("customer_id")
          .join([rfm, beh, cat_share, ch_share]).reset_index())
    df[["recency_days", "frequency", "monetary", "avg_order_value"]] = \
        df[["recency_days", "frequency", "monetary", "avg_order_value"]].fillna(
            {"recency_days": 365, "frequency": 0, "monetary": 0, "avg_order_value": 0})
    return df.fillna(0)


# Features actually fed to the clustering algorithm
CLUSTER_FEATURES = [
    # behaviour (RFM)
    "recency_days", "frequency", "monetary", "avg_order_value",
    # behaviour (other). NOTE: return_rate is deliberately NOT clustered on (pure noise
    # here) - it is still profiled per segment afterwards.
    "discount_usage",
    # preferences
    "ch_Web", "ch_Mobile App", "ch_Store",
    "cat_Electronics", "cat_Fashion", "cat_Home & Kitchen", "cat_Groceries",
    # demographics
    "age", "annual_income_k", "tenure_years",
]
SKEWED = ["frequency", "monetary", "avg_order_value"]  # log-transformed before scaling


def prepare_matrix(df):
    X = df[CLUSTER_FEATURES].copy()
    X[SKEWED] = np.log1p(X[SKEWED])
    return StandardScaler().fit_transform(X), X


# --------------------------------------------------------------- 3. CHOOSE k
def stability(Xs, k, n_boot=15, frac=0.8):
    """Bootstrap stability: fit K-Means on two random 80% subsamples, label ALL customers
    with each model and compare (Adjusted Rand Index). 1.0 = identical segments every time."""
    rng = np.random.default_rng(RANDOM_STATE)
    aris = []
    for b in range(n_boot):
        i1 = rng.choice(len(Xs), int(frac * len(Xs)), replace=False)
        i2 = rng.choice(len(Xs), int(frac * len(Xs)), replace=False)
        m1 = KMeans(k, n_init=5, random_state=b).fit(Xs[i1])
        m2 = KMeans(k, n_init=5, random_state=b + 100).fit(Xs[i2])
        aris.append(adjusted_rand_score(m1.predict(Xs), m2.predict(Xs)))
    return float(np.mean(aris))


def evaluate_k(Xs, k_range=range(2, 11)):
    rows = []
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=20, random_state=RANDOM_STATE).fit(Xs)
        rows.append(dict(k=k, inertia=km.inertia_, stability=stability(Xs, k),
                         silhouette=silhouette_score(Xs, km.labels_),
                         davies_bouldin=davies_bouldin_score(Xs, km.labels_),
                         calinski_harabasz=calinski_harabasz_score(Xs, km.labels_)))
    res = pd.DataFrame(rows)
    res.to_csv(TAB / "k_selection_metrics.csv", index=False)

    fig, ax = plt.subplots(1, 4, figsize=(21, 4.5))
    ax[0].plot(res.k, res.inertia, "o-", color=PALETTE[0]); ax[0].set_title("Elbow method (inertia)")
    ax[1].plot(res.k, res.silhouette, "o-", color=PALETTE[2]); ax[1].set_title("Silhouette score (higher = better)")
    ax[2].plot(res.k, res.davies_bouldin, "o-", color=PALETTE[3]); ax[2].set_title("Davies-Bouldin (lower = better)")
    ax[3].plot(res.k, res.stability, "o-", color=PALETTE[4]); ax[3].set_title("Bootstrap stability (ARI, higher = better)")
    for a in ax: a.set_xlabel("Number of clusters (k)")
    plt.tight_layout(); fig.savefig(FIG / "01_choose_k.png", dpi=150); plt.close(fig)
    return res


def choose_k(ks, lo=MIN_SEGMENTS, hi=MAX_SEGMENTS):
    """Pick k in a business-actionable range (MIN_SEGMENTS..MAX_SEGMENTS) by combining four metrics.
    k=2/3 splits are statistically compact but too coarse to target (they merge groups with
    opposite needs), so marketing sets a minimum of 4 segments - see docs/report.md.
    Raw silhouette keeps rising as k grows (tiny outlier clusters), so we rank
    silhouette, Davies-Bouldin, Calinski-Harabasz and bootstrap stability together."""
    c = ks[(ks.k >= lo) & (ks.k <= hi)].copy()
    c["score"] = (c.silhouette.rank() + c.calinski_harabasz.rank()
                  + (-c.davies_bouldin).rank() + 2 * c.stability.rank())  # stability double-weighted
    c.to_csv(TAB / "k_selection_ranked.csv", index=False)
    return int(c.sort_values(["score", "k"], ascending=[False, True]).iloc[0]["k"])


# -------------------------------------------------------------- 4. MODELS
def compare_models(Xs, k, truth=None):
    models = {
        "K-Means": KMeans(n_clusters=k, n_init=30, random_state=RANDOM_STATE),
        "Hierarchical (Ward)": AgglomerativeClustering(n_clusters=k, linkage="ward"),
        "Gaussian Mixture": GaussianMixture(n_components=k, n_init=5, random_state=RANDOM_STATE),
    }
    rows, labels = [], {}
    for name, m in models.items():
        lab = m.fit_predict(Xs); labels[name] = lab
        row = dict(model=name, silhouette=silhouette_score(Xs, lab),
                   davies_bouldin=davies_bouldin_score(Xs, lab),
                   calinski_harabasz=calinski_harabasz_score(Xs, lab))
        if truth is not None:
            row["adjusted_rand_vs_hidden_truth"] = adjusted_rand_score(truth, lab)
        rows.append(row)
    res = pd.DataFrame(rows).round(4)
    res.to_csv(TAB / "model_comparison.csv", index=False)
    return res, labels


# -------------------------------------------------------------- 5. PROFILE
# Archetype "recipes": +1 / -1 weights on z-scored segment means (positive = should be high)
ARCHETYPES = {
    "Premium Loyalists":      dict(monetary=1, avg_order_value=1, frequency=1, annual_income_k=1, recency_days=-1, discount_usage=-1),
    "Young Digital Shoppers": dict(age=-1.5, **{"ch_Mobile App": 1}, ch_Web=1, tenure_years=-.5, cat_Fashion=.5),
    "Budget Families":        dict(discount_usage=1.5, ch_Store=1, cat_Groceries=1, **{"cat_Home & Kitchen": 1}, annual_income_k=-.5),
    "Occasional Browsers":    dict(frequency=-1.5, monetary=-1, recency_days=1, tenure_years=-.5),
    "At-Risk Veterans":       dict(age=1, tenure_years=1, recency_days=1.5, ch_Store=.5, frequency=-.3, **{"ch_Mobile App": -1}),
}


def name_segments(df):
    """Optimally assign one archetype name to each cluster (Hungarian algorithm).
    Falls back to descriptive generic names if k != number of archetypes."""
    from scipy.optimize import linear_sum_assignment
    feats = sorted({f for r in ARCHETYPES.values() for f in r})
    means = df.groupby("cluster_id")[feats].mean()
    z = (means - df[feats].mean()) / df[feats].std(ddof=0)
    if len(means) != len(ARCHETYPES):
        out = {}
        for cid, row in z.iterrows():
            val = "High-value" if row["monetary"] > .5 else "Low-value" if row["monetary"] < -.5 else "Mid-value"
            act = "recently active" if row["recency_days"] < -.2 else "lapsing" if row["recency_days"] > .5 else "moderately active"
            out[cid] = f"Segment {cid + 1}: {val}, {act}"
        return out
    arche = list(ARCHETYPES)
    score = np.array([[sum(w * z.loc[cid, f] for f, w in ARCHETYPES[a].items()) for a in arche] for cid in z.index])
    r, c = linear_sum_assignment(-score)
    return {z.index[i]: arche[j] for i, j in zip(r, c)}


ACTIONS = {
    "Premium Loyalists": "VIP programme, early access to launches, personal concierge. Avoid heavy discounting - they buy at full price.",
    "Young Digital Shoppers": "Mobile-first campaigns, social/influencer content, referral rewards, flash sales on Fashion & Electronics.",
    "Budget Families": "Bundle & bulk offers on Groceries / Home, in-store loyalty points, weekly deal flyers.",
    "Occasional Browsers": "Welcome journey, abandoned-cart reminders, first-repeat-purchase incentive, personalised recommendations.",
    "At-Risk Veterans": "Win-back campaign, 'we miss you' offer, store-visit invitations, phone/SMS outreach, feedback survey.",
}


def profile_segments(df):
    num = ["age", "annual_income_k", "tenure_years", "recency_days", "frequency", "monetary",
           "avg_order_value", "discount_usage", "return_rate"]
    prof = df.groupby("segment")[num].mean()
    prof.insert(0, "customers", df.groupby("segment").size())
    prof.insert(1, "pct_customers", (prof["customers"] / len(df) * 100))
    prof["total_revenue"] = df.groupby("segment")["monetary"].sum()
    prof["pct_revenue"] = prof["total_revenue"] / prof["total_revenue"].sum() * 100
    for c in [c for c in df.columns if c.startswith(("ch_", "cat_"))]:
        prof[c] = df.groupby("segment")[c].mean()
    prof["top_category"] = prof[[c for c in prof.columns if c.startswith("cat_")]].idxmax(axis=1).str[4:]
    prof["top_channel"] = prof[[c for c in prof.columns if c.startswith("ch_")]].idxmax(axis=1).str[3:]
    prof["recommended_action"] = [ACTIONS.get(s, "Review segment profile and design a tailored campaign.") for s in prof.index]
    return prof.round(3)


# -------------------------------------------------------------- 6. VISUALS
def plot_pca(Xs, df):
    pca = PCA(n_components=2, random_state=RANDOM_STATE)
    Z = pca.fit_transform(Xs)
    df["pc1"], df["pc2"] = Z[:, 0], Z[:, 1]
    fig, ax = plt.subplots(figsize=(9, 6.5))
    for i, (seg, g) in enumerate(df.groupby("segment")):
        ax.scatter(g.pc1, g.pc2, s=14, alpha=.65, color=seg_color(seg, i), label=f"{seg} (n={len(g)})")
    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]:.0%} variance)")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]:.0%} variance)")
    ax.set_title("Customer segments in 2-D (PCA projection)"); ax.legend(markerscale=2, fontsize=9)
    plt.tight_layout(); fig.savefig(FIG / "02_segments_pca.png", dpi=150); plt.close(fig)


def plot_sizes_revenue(prof):
    fig, ax = plt.subplots(1, 2, figsize=(14, 5))
    order = prof.sort_values("customers", ascending=False).index
    ax[0].pie(prof.loc[order, "customers"], labels=order, autopct="%1.0f%%", colors=[seg_color(o, i) for i, o in enumerate(order)], startangle=90,
              wedgeprops=dict(width=.45, edgecolor="white"))
    ax[0].set_title("Share of customers")
    x = np.arange(len(order)); w = .38
    ax[1].bar(x - w/2, prof.loc[order, "pct_customers"], w, label="% customers", color=PALETTE[0])
    ax[1].bar(x + w/2, prof.loc[order, "pct_revenue"], w, label="% revenue", color=PALETTE[1])
    ax[1].set_xticks(x); ax[1].set_xticklabels(order, rotation=20, ha="right"); ax[1].set_ylabel("%")
    ax[1].set_title("Customers vs revenue contribution"); ax[1].legend()
    plt.tight_layout(); fig.savefig(FIG / "03_segment_size_revenue.png", dpi=150); plt.close(fig)


def plot_rfm_boxes(df):
    fig, ax = plt.subplots(1, 4, figsize=(19, 5))
    order = df.groupby("segment")["monetary"].mean().sort_values(ascending=False).index
    for a, col, t in zip(ax, ["recency_days", "frequency", "monetary", "avg_order_value"],
                         ["Recency (days since last order)", "Frequency (orders)", "Monetary (total spend, INR)", "Avg order value (INR)"]):
        sns.boxplot(data=df, x="segment", y=col, order=order, palette=seg_palette(order), ax=a, fliersize=1.5)
        a.set_title(t); a.set_xlabel(""); a.tick_params(axis="x", rotation=40)
        for lbl in a.get_xticklabels(): lbl.set_ha("right")
    plt.tight_layout(); fig.savefig(FIG / "04_rfm_by_segment.png", dpi=150); plt.close(fig)


def plot_heatmap(df):
    cols = ["recency_days", "frequency", "monetary", "avg_order_value", "discount_usage", "return_rate",
            "age", "annual_income_k", "tenure_years"]
    z = df.groupby("segment")[cols].mean()
    z = (z - z.mean()) / z.std(ddof=0)
    fig, ax = plt.subplots(figsize=(11, 4.8))
    sns.heatmap(z, annot=True, fmt=".1f", cmap="RdBu_r", center=0, linewidths=.5, ax=ax,
                cbar_kws={"label": "z-score vs. average segment"})
    ax.set_title("Segment fingerprint (red = above average, blue = below)"); ax.set_ylabel("")
    plt.xticks(rotation=30, ha="right"); plt.tight_layout()
    fig.savefig(FIG / "05_segment_heatmap.png", dpi=150); plt.close(fig)


def plot_preferences(prof):
    cats = [c for c in prof.columns if c.startswith("cat_")]
    chs = [c for c in prof.columns if c.startswith("ch_")]
    fig, ax = plt.subplots(1, 2, figsize=(17, 5.5))
    sns.heatmap(prof[cats].rename(columns=lambda c: c[4:]) * 100, annot=True, fmt=".0f", cmap="YlGnBu", ax=ax[0],
                cbar_kws={"label": "% of orders"}); ax[0].set_title("Category preference by segment"); ax[0].set_ylabel("")
    sns.heatmap(prof[chs].rename(columns=lambda c: c[3:]) * 100, annot=True, fmt=".0f", cmap="YlOrBr", ax=ax[1],
                cbar_kws={"label": "% of orders"}); ax[1].set_title("Channel preference by segment"); ax[1].set_ylabel("")
    plt.tight_layout(); fig.savefig(FIG / "06_preferences.png", dpi=150); plt.close(fig)


def plot_demographics(df):
    fig, ax = plt.subplots(1, 3, figsize=(18, 5))
    order = df.groupby("segment")["age"].mean().sort_values().index
    sns.violinplot(data=df, x="segment", y="age", order=order, palette=seg_palette(order), ax=ax[0], inner="quartile")
    ax[0].set_title("Age distribution"); 
    sns.scatterplot(data=df, x="annual_income_k", y="monetary", hue="segment", palette=seg_palette(sorted(df.segment.unique())), s=14, alpha=.6, ax=ax[1])
    ax[1].set_title("Income vs total spend"); ax[1].set_xlabel("Annual income (INR '000)"); ax[1].set_ylabel("Total spend (INR)")
    ax[1].legend(fontsize=7, markerscale=1.5)
    sns.scatterplot(data=df, x="frequency", y="recency_days", hue="segment", palette=seg_palette(sorted(df.segment.unique())), s=14, alpha=.6, ax=ax[2], legend=False)
    ax[2].set_title("Frequency vs recency")
    for a in ax[:1]: a.tick_params(axis="x", rotation=30)
    plt.tight_layout(); fig.savefig(FIG / "07_demographics.png", dpi=150); plt.close(fig)


def plot_radar(df):
    cols = ["recency_days", "frequency", "monetary", "avg_order_value", "discount_usage", "annual_income_k", "tenure_years"]
    labels = ["Recency", "Frequency", "Monetary", "Avg order", "Discount use", "Income", "Tenure"]
    g = df.groupby("segment")[cols].mean()
    g = (g - g.min()) / (g.max() - g.min())
    ang = np.linspace(0, 2 * np.pi, len(cols), endpoint=False).tolist(); ang += ang[:1]
    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    for i, (seg, row) in enumerate(g.iterrows()):
        v = row.tolist() + row.tolist()[:1]
        ax.plot(ang, v, color=seg_color(seg, i), lw=2, label=seg); ax.fill(ang, v, color=seg_color(seg, i), alpha=.1)
    ax.set_xticks(ang[:-1]); ax.set_xticklabels(labels); ax.set_yticklabels([])
    ax.set_title("Segment radar (normalised 0-1)", pad=20); ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.1), fontsize=9)
    plt.tight_layout(); fig.savefig(FIG / "08_radar.png", dpi=150, bbox_inches="tight"); plt.close(fig)


def plot_city_gender(df):
    fig, ax = plt.subplots(1, 2, figsize=(15, 5))
    ct_city = pd.crosstab(df["city"], df["segment"], normalize="index").mul(100)
    ct_city.plot(kind="bar", stacked=True, ax=ax[0], color=[seg_color(c, i) for i, c in enumerate(ct_city.columns)], width=.8)
    ax[0].set_title("Segment mix by city"); ax[0].set_ylabel("% of customers"); ax[0].legend(fontsize=7, loc="upper right"); ax[0].tick_params(axis="x", rotation=30)
    ct_g = pd.crosstab(df["gender"], df["segment"], normalize="index").mul(100)
    ct_g.plot(kind="bar", stacked=True, ax=ax[1], color=[seg_color(c, i) for i, c in enumerate(ct_g.columns)], width=.6, legend=False)
    ax[1].set_title("Segment mix by gender"); ax[1].set_ylabel("% of customers"); ax[1].tick_params(axis="x", rotation=0)
    plt.tight_layout(); fig.savefig(FIG / "09_city_gender_mix.png", dpi=150); plt.close(fig)


def plot_feature_importance(Xs, labels, names):
    """Which features separate the segments most? (ANOVA-style F ratio on scaled data)"""
    from sklearn.feature_selection import f_classif
    F, _ = f_classif(Xs, labels)
    imp = pd.Series(F, index=names).sort_values()
    fig, ax = plt.subplots(figsize=(8, 6))
    imp.plot(kind="barh", color=PALETTE[0], ax=ax); ax.set_title("What drives the segmentation? (F-statistic)")
    plt.tight_layout(); fig.savefig(FIG / "10_feature_importance.png", dpi=150); plt.close(fig)
    imp.sort_values(ascending=False).round(1).to_csv(TAB / "feature_importance.csv", header=["F_statistic"], index_label="feature")


# ----------------------------------------------------------------- MAIN
def main(k=None):
    customers, tx = load_data()
    df = build_features(customers, tx)
    Xs, _ = prepare_matrix(df)
    print(f"Customers: {len(df):,} | Features used: {len(CLUSTER_FEATURES)}")

    ks = evaluate_k(Xs)
    print("\nK selection:\n", ks.round(3).to_string(index=False))
    if k is None:
        k = choose_k(ks)
    print(f"\nChosen k = {k}")

    truth_path = DATA / "_ground_truth_for_validation_only.csv"
    truth = pd.read_csv(truth_path).set_index("customer_id").loc[df["customer_id"], "true_persona"].values \
        if truth_path.exists() else None
    comp, labels = compare_models(Xs, k, truth)
    print("\nModel comparison:\n", comp.to_string(index=False))

    df["cluster_id"] = labels["K-Means"]            # final model: K-Means
    mapping = name_segments(df)
    df["segment"] = df["cluster_id"].map(mapping)

    prof = profile_segments(df)
    prof.to_csv(TAB / "segment_profiles.csv")
    print("\nSegment profiles:\n", prof[["customers", "pct_customers", "recency_days", "frequency",
                                         "monetary", "pct_revenue", "top_category", "top_channel"]].to_string())

    if truth is not None:
        ct = pd.crosstab(df["segment"], truth, rownames=["found segment"], colnames=["hidden truth"])
        ct.to_csv(TAB / "validation_crosstab.csv"); print("\nValidation vs hidden truth:\n", ct.to_string())

    plot_pca(Xs, df); plot_sizes_revenue(prof); plot_rfm_boxes(df); plot_heatmap(df)
    plot_preferences(prof); plot_demographics(df); plot_radar(df); plot_city_gender(df)
    plot_feature_importance(Xs, df["cluster_id"], CLUSTER_FEATURES)

    # exports for Power BI / Excel
    df.drop(columns=["pc1", "pc2"]).to_csv(ROOT / "outputs" / "customers_segmented.csv", index=False)
    df[["customer_id", "segment", "pc1", "pc2"]].to_csv(TAB / "segment_pca_coordinates.csv", index=False)
    tx.merge(df[["customer_id", "segment"]], on="customer_id").to_csv(ROOT / "outputs" / "transactions_segmented.csv", index=False)
    print("\nDone. Outputs in:", ROOT / "outputs")


if __name__ == "__main__":
    main()
