"""
Generate a realistic synthetic retail dataset (customers + transactions).

Why synthetic? It keeps the project fully self-contained and reproducible.
To use real data instead (e.g. Kaggle "Online Retail II" or "Mall Customers"),
replace data/customers.csv and data/transactions.csv with files that follow the
same schema (see README.md).

Customers are drawn from 5 hidden "personas" with different demographics and
buying behaviour. The clustering algorithm never sees the persona label, so we
can later check how well unsupervised learning recovers the real structure.
"""
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 42
N_CUSTOMERS = 2500
SNAPSHOT_DATE = pd.Timestamp("2025-12-31")
START_DATE = pd.Timestamp("2025-01-01")

CATEGORIES = ["Electronics", "Fashion", "Home & Kitchen", "Beauty",
              "Groceries", "Sports", "Books"]
CHANNELS = ["Web", "Mobile App", "Store"]
CITIES = ["Chennai", "Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Kolkata", "Pune"]

# age(mean,sd) | income(mean,sd; INR thousands/yr) | orders per year | avg basket (INR)
# rec = mean days since last purchase | cat = category weights | ch = channel weights
# disc = probability an order uses a discount | tenure(mean,sd; years)
PERSONAS = {
    "Premium Loyalists": dict(share=0.14, age=(41, 7), income=(1800, 300), orders=26, basket=3200,
        rec=25, cat=[.28, .20, .17, .13, .07, .08, .07], ch=[.35, .45, .20], disc=.15, tenure=(4.5, 1.5)),
    "Young Digital Shoppers": dict(share=0.26, age=(25, 4), income=(650, 180), orders=17, basket=1100,
        rec=40, cat=[.26, .30, .06, .16, .06, .10, .06], ch=[.30, .62, .08], disc=.55, tenure=(1.8, 1.0)),
    "Budget Families": dict(share=0.25, age=(38, 6), income=(720, 150), orders=14, basket=1500,
        rec=55, cat=[.06, .12, .27, .08, .35, .06, .06], ch=[.15, .20, .65], disc=.80, tenure=(3.2, 1.6)),
    "Occasional Browsers": dict(share=0.20, age=(34, 11), income=(900, 300), orders=3, basket=1400,
        rec=190, cat=[.20, .18, .15, .10, .12, .13, .12], ch=[.45, .35, .20], disc=.50, tenure=(1.5, 1.2)),
    "At-Risk Veterans": dict(share=0.15, age=(52, 8), income=(1100, 250), orders=7, basket=2100,
        rec=240, cat=[.15, .10, .24, .08, .20, .05, .18], ch=[.25, .05, .70], disc=.35, tenure=(5.5, 1.8)),
}


def build_customers(rng):
    names = list(PERSONAS)
    shares = np.array([PERSONAS[n]["share"] for n in names])
    persona = rng.choice(names, size=N_CUSTOMERS, p=shares / shares.sum())
    rows = []
    for i, p in enumerate(persona):
        cfg = PERSONAS[p]
        rows.append(dict(
            customer_id=f"C{10000 + i}",
            age=int(np.clip(rng.normal(*cfg["age"]), 18, 80)),
            gender=rng.choice(["Female", "Male"], p=[.52, .48]),
            city=rng.choice(CITIES),
            annual_income_k=round(float(np.clip(rng.normal(*cfg["income"]), 200, 3500)), 1),
            tenure_years=round(float(np.clip(rng.normal(*cfg["tenure"]), 0.1, 9)), 2),
            _persona=p,
        ))
    return pd.DataFrame(rows)


def build_transactions(customers, rng):
    rows, tid = [], 1
    span = (SNAPSHOT_DATE - START_DATE).days  # 364
    for c in customers.itertuples():
        cfg = PERSONAS[c._persona if hasattr(c, "_persona") else c[-1]]
        n_orders = max(1, rng.poisson(cfg["orders"] * rng.uniform(.7, 1.3)))
        # most recent purchase: exponential "days ago"; earlier orders are spread before it
        last_ago = int(np.clip(rng.exponential(cfg["rec"]), 0, span - 1))
        earlier = rng.integers(last_ago, span + 1, size=n_orders - 1)
        days_ago = np.concatenate([[last_ago], earlier]).astype(int)
        scale = 0.75 + 0.25 * (c.annual_income_k / cfg["income"][0])  # income nudges basket
        for d in days_ago:
            cat = rng.choice(CATEGORIES, p=np.array(cfg["cat"]) / sum(cfg["cat"]))
            ch = rng.choice(CHANNELS, p=cfg["ch"])
            disc_pct = int(rng.choice([10, 15, 20, 30])) if rng.random() < cfg["disc"] else 0
            gross = rng.gamma(shape=3.0, scale=cfg["basket"] * scale / 3.0)
            rows.append(dict(
                transaction_id=f"T{tid:07d}",
                customer_id=c.customer_id,
                order_date=(SNAPSHOT_DATE - pd.Timedelta(days=int(d))).date(),
                category=cat,
                channel=ch,
                quantity=int(rng.poisson(2.5)) + 1,
                discount_pct=disc_pct,
                order_value=round(gross * (1 - disc_pct / 100), 2),
                returned=int(rng.random() < 0.06),
            ))
            tid += 1
    return pd.DataFrame(rows)


def main():
    rng = np.random.default_rng(SEED)
    out = Path(__file__).resolve().parents[1] / "data"
    out.mkdir(exist_ok=True)
    customers = build_customers(rng)
    tx = build_transactions(customers, rng)
    # the hidden persona goes in a SEPARATE file used only for validation
    customers[["customer_id", "_persona"]].rename(columns={"_persona": "true_persona"}) \
        .to_csv(out / "_ground_truth_for_validation_only.csv", index=False)
    customers.drop(columns="_persona").to_csv(out / "customers.csv", index=False)
    tx.to_csv(out / "transactions.csv", index=False)
    print(f"customers: {len(customers):,} | transactions: {len(tx):,}")


if __name__ == "__main__":
    main()
