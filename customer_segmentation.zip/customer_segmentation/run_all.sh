#!/usr/bin/env bash
# Reproduce the whole project: data -> features -> clustering -> charts & tables
set -e
cd "$(dirname "$0")"
pip install -r requirements.txt
python src/generate_data.py      # skip this line if you use your own data
python src/segmentation.py
echo "Done. See outputs/ and docs/report.md"
