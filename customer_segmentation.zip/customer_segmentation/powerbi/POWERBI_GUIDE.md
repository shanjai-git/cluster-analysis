# Power BI Dashboard Guide

Python produces the segments; Power BI is the interactive layer for business users.
*(Note: this guide was written alongside the Python pipeline and the DAX has not been opened in Power BI Desktop by the author - if a measure errors, check table/column names first.)*

## 1. Load the data
`Home -> Get data -> Text/CSV`, load both files from `outputs/`:
- `customers_segmented.csv` (1 row per customer, includes `segment`)
- `transactions_segmented.csv` (1 row per order)

In Power Query, **delete the `segment` column from `transactions_segmented`** so the segment lives only in the customer table (avoids ambiguous filtering). Set `order_date` type to *Date*.

## 2. Model
Create a relationship: `customers_segmented[customer_id]` (1) -> `transactions_segmented[customer_id]` (*), single direction.

## 3. DAX measures
Create a table `_Measures` and add:

```DAX
Customers = DISTINCTCOUNT ( customers_segmented[customer_id] )

Net Revenue =
CALCULATE ( SUM ( transactions_segmented[order_value] ), transactions_segmented[returned] = 0 )

Revenue Share % =
DIVIDE ( [Net Revenue], CALCULATE ( [Net Revenue], ALL ( customers_segmented[segment] ) ) )

Customer Share % =
DIVIDE ( [Customers], CALCULATE ( [Customers], ALL ( customers_segmented[segment] ) ) )

Orders = CALCULATE ( COUNTROWS ( transactions_segmented ), transactions_segmented[returned] = 0 )

Avg Order Value = DIVIDE ( [Net Revenue], [Orders] )

Revenue per Customer = DIVIDE ( [Net Revenue], [Customers] )

Discount Usage % =
DIVIDE ( CALCULATE ( COUNTROWS ( transactions_segmented ), transactions_segmented[discount_pct] > 0 ),
         COUNTROWS ( transactions_segmented ) )

Avg Recency (days) = AVERAGE ( customers_segmented[recency_days] )
Avg Frequency      = AVERAGE ( customers_segmented[frequency] )
Avg Age            = AVERAGE ( customers_segmented[age] )
```

## 4. Suggested report pages

**Page 1 - Overview:** cards (Customers, Net Revenue, AOV) -> donut of `Customers` by `segment` -> clustered bar of `Customer Share %` vs `Revenue Share %` by segment -> slicers for `city`, `gender`.

**Page 2 - Segment profile:** matrix with `segment` rows and measures (`Avg Age`, `Avg Recency (days)`, `Avg Frequency`, `Avg Order Value`, `Discount Usage %`). Apply conditional-formatting colour scales to the columns (this reproduces the heatmap in `05_segment_heatmap.png`).

**Page 3 - Preferences:** matrix `segment` x `category` (values = `Orders`, shown as % of row total) and a 100% stacked column of `Orders` by `channel` and `segment`.

**Page 4 - Customer drill-down:** table with `customer_id`, `segment`, `recency_days`, `frequency`, `monetary`; filter to *At-Risk Veterans* for the win-back call list; export to CSV from the visual menu.

Use the same colours as the Python charts for consistency:
Premium Loyalists `#E4A81C` | Young Digital Shoppers `#4C78A8` | Budget Families `#54A24B` | Occasional Browsers `#9AA0A6` | At-Risk Veterans `#E45756`.

## 5. (Optional) Run the clustering inside Power BI
Requires Python enabled in Power BI (`File -> Options -> Python scripting`) with scikit-learn installed.
In Power Query, load `customers_segmented.csv`, then `Transform -> Run Python script`:

```python
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

feats = ["recency_days","frequency","monetary","avg_order_value","discount_usage",
         "ch_Web","ch_Mobile App","ch_Store","cat_Electronics","cat_Fashion",
         "cat_Home & Kitchen","cat_Groceries","age","annual_income_k","tenure_years"]
X = dataset[feats].copy()
for c in ["frequency","monetary","avg_order_value"]:
    X[c] = np.log1p(X[c])
dataset["cluster_pbi"] = KMeans(n_clusters=5, n_init=30, random_state=42).fit_predict(StandardScaler().fit_transform(X))
```
Cluster numbers (0-4) are arbitrary labels; use the profile matrix to name them, or just keep the `segment` column produced by the full pipeline.
