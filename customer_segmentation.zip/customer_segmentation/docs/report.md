# Customer Segmentation - Findings Report

**Data:** 2,500 customers, 32,877 orders (Jan-Dec 2025), net revenue ~INR 53.6 M (returned orders excluded)
**Method:** RFM + behaviour + preference + demographic features -> log/standard scaling -> K-Means (k = 5)
**Currency** is assumed to be INR; the dataset is synthetic (see *Limitations*).

---

## 1. Executive summary

Five distinct customer groups emerge. The headline finding is concentration of value:

> **14% of customers (Premium Loyalists) generate ~50% of revenue.** Meanwhile 17% of customers (Occasional Browsers) generate under 3%.

| Segment | % customers | % revenue | Who they are | What they want |
|---|---|---|---|---|
| **Premium Loyalists** | 14.4% | 49.6% | Age ~41, income ~1.77 M, 25 orders/yr, last order ~25 days ago, AOV ~3,100, use discounts on only 15% of orders | Electronics & Fashion, mostly via the mobile app (46%) |
| **Young Digital Shoppers** | 26.6% | 19.1% | Age ~25, income ~0.66 M, 17 orders/yr, AOV ~990, newer customers (1.8 yrs) | Fashion & Electronics on mobile (62% of orders) |
| **Budget Families** | 26.4% | 19.7% | Age ~38, income ~0.73 M, 13 orders/yr, **80% of orders discounted** | Groceries & Home in store (64%) |
| **Occasional Browsers** | 17.2% | 2.8% | Age ~33, 3 orders/yr, last order ~177 days ago, new (1.7 yrs) | Web-first (48%), no strong category habit |
| **At-Risk Veterans** | 15.3% | 8.9% | Age ~51, long tenure (5.4 yrs), 6.8 orders/yr but last order ~195 days ago | Home & Kitchen in store (73%) - barely use the app |

Charts: `outputs/figures/03_segment_size_revenue.png`, `05_segment_heatmap.png`, `06_preferences.png`.

## 2. Recommended actions (hypotheses to A/B test)

1. **Premium Loyalists - protect.** Launch a VIP tier with early access and service perks. Don't blanket-discount: they already buy at full price, so discounts would just erode margin. Losing even a fraction of this group costs far more than any other segment.
2. **Young Digital Shoppers - grow.** Mobile-first push notifications, referral rewards, Fashion/Electronics drops. They have low income *today* but are young and recently acquired, so they are the pipeline for tomorrow's loyalists. Test bundles to lift AOV from ~990.
3. **Budget Families - serve efficiently.** Grocery + Home bundles, in-store loyalty points, weekly deal flyers. They respond to price (80% discounted orders), so focus on basket size rather than deeper discounts.
4. **Occasional Browsers - convert or stop spending.** Welcome journey, cart-abandonment reminders, a first-repeat-purchase incentive. Cap acquisition/retention spend: this segment contributes <3% of revenue.
5. **At-Risk Veterans - win back (most urgent).** ~15% of customers who bought regularly with high tenure but have gone quiet for ~6 months. They have ~INR 4.75 M of 2025 revenue at stake. They prefer stores and phone-friendly channels, so use SMS/phone/in-store invitations rather than app notifications; add a short feedback survey to learn why they left.

## 3. How the segments were built

**Features (15)** - Behaviour: recency, frequency, monetary, average order value, discount usage. Preferences: share of orders by channel (Web / App / Store) and by 4 main categories. Demographics: age, income, tenure. Spend variables were log-transformed (heavily right-skewed), then all features standardised.

**Choosing k.** Four criteria were compared for k = 2-10 (`outputs/figures/01_choose_k.png`): silhouette, Davies-Bouldin, Calinski-Harabasz and bootstrap stability (re-clustering random 80% subsamples and checking they agree).

- k = 3 is the most compact and stable split, but it merges customers with opposite needs (e.g. discount-hungry store families with lapsing veterans), which is not useful for targeting.
- Marketing needs at least 4 distinct groups, so selection was restricted to **k = 4-7**. Within that range **k = 5 wins** (stability 0.98, silhouette 0.30). This minimum is an explicit business choice (`MIN_SEGMENTS` in the code), not something the data dictated.

**Algorithm comparison.** K-Means, Ward hierarchical clustering and Gaussian Mixture give very similar answers (silhouette 0.30 / 0.29 / 0.29), so the segmentation is not an artefact of one algorithm. K-Means was chosen as the simplest to explain and deploy.

**Naming.** Clusters are mapped to segment names by optimal one-to-one matching against archetype "recipes" (e.g. Premium = high spend + high frequency + low recency + low discount use), see `name_segments()`.

## 4. What drives the segmentation

Top separating features (F-statistic, `outputs/tables/feature_importance.csv`): **store-channel share, purchase frequency, income, average order value, total spend, age.** Channel and life stage matter as much as pure spend, which suggests a purely RFM-based segmentation would blur together groups like Young Digital Shoppers and Budget Families that behave similarly on spend but differ sharply in channel, age and discount use.

## 5. Validation

Because the data is synthetic, each customer carries a hidden "true persona" that the algorithm never saw. K-Means recovered it with an Adjusted Rand Index of **0.91** and placed **96%** of customers in the "right" segment (`outputs/tables/validation_crosstab.csv`). Most errors are Occasional Browsers mixed with neighbouring groups, which is expected as they have too few orders to profile reliably.

## 6. Limitations - please read

- **Synthetic data.** Segments were deliberately generated to be separable, so recovery scores (ARI 0.91) will be *higher* than on real data. On real data expect fuzzier boundaries; the moderate silhouette (0.30) already indicates overlapping groups.
- **Return rate is noisy for low-order customers.** One returned order out of one is a 100% return rate. The apparent high return rate among Occasional Browsers (`05_segment_heatmap.png`) is a small-sample artefact, not an insight.
- **One-year snapshot.** No seasonality, and recency is measured against 31 Dec 2025. Re-run on a rolling basis.
- **K-Means assumes roughly spherical clusters** and a hard assignment; customers between two segments are forced into one.
- **Descriptive, not causal.** The recommended actions are hypotheses; validate with controlled experiments before committing budget.
